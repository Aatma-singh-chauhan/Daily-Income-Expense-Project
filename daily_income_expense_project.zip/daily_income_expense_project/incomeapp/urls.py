from django.contrib import admin
from django.urls import path
from .import views as v

urlpatterns = [
    path("admin/",admin.site.urls),
    path("income",v.add_income),
    path("inc_data",v.list_income,name="inc_data"),
    path("delete1/<int:id>",v.delete_income),
    path("data_inc_data/<int:id>",v.data_edit),
    path('income_search',v.income_search, name='income_search'),
    path("inct/<str:inctp>",v.sort_by_income_type,name="income_sort"),
]
