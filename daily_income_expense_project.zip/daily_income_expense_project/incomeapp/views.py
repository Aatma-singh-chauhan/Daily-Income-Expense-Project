from django.shortcuts import render,redirect
from .models import IncomeForm
from .models import Income
from django.contrib.auth.models import User
# Create your views here.

def add_income(req):    # it will generate Inbuilt form because of IncomeForm and send to data to db.sqlite3
    uid=req.session.get("uid")
    if req.method=="POST":
        # f=IncomeForm(req.POST)
        income=req.POST.get("income")
        income_type=req.POST.get("income_type")
        income_date=req.POST.get("income_date")
        description=req.POST.get("description")

        inc=Income()

        inc.income=income
        inc.income_type=income_type
        inc.income_date=income_date
        inc.description=description
        inc.user=User.objects.get(id=uid)
        inc.save()

        # f.save()
        return redirect("/")
    else:
        f=IncomeForm
        context={"form":f}
        return render(req,'add_income.html',context)
# =======================================================================================
def list_income(request):
    uid=request.session.get("uid")
    inc_list=Income.objects.filter(user=uid)
    inct=set()
    for i in inc_list:
        inct.add(i.income_type)
    context={"inct":inc_list,"incoms":inct}
    return render(request,'data_list.html',context)
# ===================================================================================
# def list_income(req):  # old one
#     uid=req.session.get('uid')# it will redirect your page only not others likewise u entering you mail and can see            
#     elist=Income.objects.filter(user=uid)   # it will retrive data from db.sqlite3 to html page
#     d={"exe":elist}
#     return render(req,"data_list.html",d)

# =====================================================================================

def delete_income(request,id):    # it is for delete 
    n=Income.objects.get(id=id)
    n.delete()
    return redirect("/")
# ========================================================================================

def data_edit(request,id):
    inc=Income.objects.get(id=id)
    if request.method=="POST":
        f=IncomeForm(request.POST,instance=inc)
        f.save()
        return redirect("/")
    else:
        f=IncomeForm(instance=inc)
        context={"x":f} 
        return render(request,"add_income.html",context)

# ============================================================================
def income_search(req):
    uid=req.session.get("uid")
    search=req.POST.get('srch')
    incl=Income.objects.filter(user=uid,description__contains=search)
    context={"inct":incl}
    return render(req,"data_list.html",context)
# ==============================================================
def sort_by_income_type(request,inctp):
    uid=request.session.get("uid")
    inclist=Income.objects.filter(user=uid)
    incom=set()
    for i in inclist:
        incom.add(i.income_type)
        inclist=Income.objects.filter(user=uid,income_type=inctp)
    context={"inct":inclist,"incoms":incom}
    return render(request,'data_list.html',context)