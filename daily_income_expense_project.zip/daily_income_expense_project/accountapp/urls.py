from django.contrib import admin
from django.urls import path
from .import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",v.home),
    path("registration",v.add_user),
    path('login_link',v.login_view),
    path("logout_link",v.logout_view),
    path('Edit_Profile_Link',v.Edit_Profile),
    path('about',v.about_us, name='about_us'),
    path('Edit_user',v.Edit_User),
]
