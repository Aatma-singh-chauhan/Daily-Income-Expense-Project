from django.shortcuts import render,redirect,HttpResponse
from .models import LoginForm
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages 

# Create your views here.

def home(req):
    context={"bal": get_balance(req),"expen":get_expense(req),"get_total":Get_Total_Balance(req)}
    return render(req,"home.html",context)


from django.contrib.auth.forms import UserCreationForm
def add_user(req):
    if req.method=="POST":
        f=UserCreationForm(req.POST)
        f.save()
        return redirect("/")
        
    else:
        f=UserCreationForm
        context={"form":f}
        return render(req,"add_user.html",context)
    
# =======================================================this is mine old one
# def login_view(req):
#     if req.method=="POST":
#         uname=req.POST.get("username")
#         passw=req.POST.get("password")
#         user=authenticate(req,username=uname,password=passw)
#         if user is not None:
#             req.session['uid']=user.id
#             login(req,user)
#             return redirect("/")
#         else:
#             f=LoginForm
#             d={"ajay":n}
#             return render(req,'login.html',d)
#     else:
#         n=LoginForm
#         d={"ajay":n}
#         return render(req,'login.html',d)
    
# ==================================================bhai saheb
def login_view(req):
    if req.method == "POST":
        uname = req.POST.get("username")
        passw = req.POST.get("password")
        
        user = authenticate(req, username=uname, password=passw)
        
        if user is not None:
            req.session['uid'] = user.id
            login(req, user)
            
            if req.POST.get("remember"):
                req.session.set_expiry(3600 * 24 * 30)  # 30 days
            else:
                req.session.set_expiry(0)  # Session expires when browser is closed
            
            # Set the successful_login variable to show success message
            successful_login = True
            return render(req, 'login.html', {'ajay': LoginForm(), 'successful_login': successful_login})
        
        else:
            login_form = LoginForm()
            context = {"ajay": login_form, "error": "Invalid credentials"}
            return render(req, 'login.html', context)
    else:
        login_form = LoginForm()
        context = {"ajay": login_form}
        return render(req, 'login.html', context)
# =========================================================another one from bhaisaheb
# def login_view(req):
#     if req.method == "POST":
#         uname = req.POST.get("username")
#         passw = req.POST.get("password")
        
#         user = authenticate(req, username=uname, password=passw)
        
#         if user is not None:
#             req.session['uid'] = user.id
#             login(req, user)
            
#             if req.POST.get("remember"):
#                 req.session.set_expiry(3600 * 24 * 30)  # 30 days
#             else:
#                 req.session.set_expiry(0)  # Session expires when the browser is closed
            
#             # Add a success message
#             messages.success(req, "Login successful. Welcome to our website!")
            
#             # Redirect to the home page after successful login
#             return redirect("/")  # Replace 'home' with the name/url of your home page view
#         else:
#             login_form = LoginForm()
#             context = {"ajay": login_form, "error": "Invalid credentials"}
#             return render(req, 'login.html', context)
#     else:
#         login_form = LoginForm()
#         context = {"ajay": login_form}
#         return render(req, 'login.html', context)
# =============================================== This is i have when i login then succesfull msg will come
# def login_view(req):
#     if req.method=="POST":
#         uname=req.POST.get("username")
#         passw=req.POST.get("password")
#         user=authenticate(req,username=uname,password=passw)
#         if user is not None:
#             login=(req,user)
#             m.success(req,"Login Successful")
#             m.info(req,"Username:"+uname+" "+"Password:"+passw)
#             return redirect("/login_link") #
#         else:
#             n=LoginForm
#             d={"ajay":n}
#             m.warning(req,"Incorrect Credentials")
#             return render(req,'login.html',d)
#     else:
#         n=LoginForm
#         d={"ajay":n}
#         return render(req,'login.html',d)
# =========================================================================================
def logout_view(req):
    logout(req)
    return redirect("/")
# ============================================this is for about

def about_us(request):
    return render(request, 'about_us.html')

# ==================================================
from incomeapp.models import Income
from expenseapp.models import Expense
def get_balance(request):
    uid=request.session.get("uid")
    incll=Income.objects.filter(user=uid)
    expll=Expense.objects.filter(user=uid)

    total_income=0
    total_expense=0

    for i in incll:
        total_income=total_income+i.income
    return total_income

    for i in expll:
        total_expense=total_expense+i.expense
    return total_income-total_expense
# =============================================
def get_expense(request):
    uid=request.session.get("uid")
    expll=Expense.objects.filter(user=uid)

    total_expense=0
    
    for i in expll:
        total_expense=total_expense+i.expense
    return total_expense

# =======================================
def Get_Total_Balance(request):
    uid=request.session.get("uid")
    f=Income.objects.filter(user=uid)
    expl=Expense.objects.filter(user=uid)

    total_income=0
    total_expense=0


    for i in f:
        total_income=total_income+i.income
    for i in expl:
        total_expense=total_expense+i.expense
    return total_income-total_expense



# ===============================================for edit profile
from .models import UserForm
from django.contrib.auth.models import User
def Edit_Profile(request):
    uid=request.session.get("uid")
    u=User.objects.get(id=uid)
    if request.method=='POST':
        f=UserForm(request.POST,instance=u)
        f.save()
        return redirect("/")
    else:    
        f=UserForm(instance=u)
        context={"updateuser":f}
        return render(request,'update_Profile.html',context)

# create customize model for edit profile go to models.py
# ===================================================for Edit only username
from .models import UserEditForm
def Edit_User(request):
    uid=request.session.get("uid")
    u=User.objects.get(id=uid)
    if request.method=='POST':
        f=UserEditForm(request.POST,instance=u)
        f.save()
        return redirect("/")
    else:    
        f=UserEditForm(instance=u)
        context={"updateuser":f}
        return render(request,'Edit_User_Profile.html',context)