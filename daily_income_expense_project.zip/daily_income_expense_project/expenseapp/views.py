from django.shortcuts import render,redirect
from .models import ExpenseForm,Expense
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from accountapp.views import get_balance

# Create your views here.

# def add_expense(req):
#     if req.method=="POST":
#         f=ExpenseForm(req.POST)
#         f.save()
#         return redirect("/")
#     else:
#         f=ExpenseForm
#         context={"form":f}
#         return render(req,"add_expense.html",context)
# ===============================================================================================================
def add_expense(req):    # it will generate Inbuilt form because of IncomeForm and send to data to db.sqlite3
    uid=req.session.get("uid")
    if req.method=="POST":
        expense=req.POST.get("expense")
        if get_balance(req)> int(expense):
            expense_type=req.POST.get("expense_type")
            expense_date=req.POST.get("expense_date")
            description=req.POST.get("description")

            exps=Expense()

            exps.expense=expense
            exps.expense_type=expense_type
            exps.expense_date=expense_date
            exps.description=description
            exps.user=User.objects.get(id=uid)
            exps.save()
            return redirect("/")
        else:
            f=ExpenseForm
            context={"exlist":f,"exp_msg":"Insufficient Balance"}
            return render(req,'add_expense.html',context)
    else:
        f=ExpenseForm
        context={"exlist":f}
        return render(req,'add_expense.html',context)
# ================================================================================
def ExpenseData(request):
    uid=request.session.get("uid")
    explisst=Expense.objects.filter(user=uid)
    expt=set()
    for i in explisst:
        expt.add(i.expense_type)
    context={"exp":explisst,"expt":expt}
    return render(request,'expense_data_list.html',context)
 # =================================================================   
# def ExpenseData(request): # old one
#     if request.method=="POST":
#         f=ExpenseForm(request.POST)
#         f.save()
#         return redirect("/")
#     else:
#         f=ExpenseForm    
       # e={"exlist":f}
       # return render(request,'expense_data_list.html',e)

# ================================================================================
def Delete_List(request,id):
    dele=Expense.objects.get(id=id)
    dele.delete()
    return redirect("/")

# =================================================================================
def ExpData_list(request,id):
    exp=Expense.objects.get(id=id)
    if request.method=="POST":
        f=ExpenseForm(request.POST,instance=exp)
        f.save()
        return redirect("/")
    else:
        f=ExpenseForm(instance=exp)
        context={"w":f} 
        return render(request,"add_expense.html",context)
    
# =============================================================================================================
def Expense_Search(req):
    search=req.POST.get('srch')
    incl=Expense.objects.filter(description__contains=search)
    context={"exp":incl}
    return render(req,"expense_data_list.html",context)
    
# ================================================================
def sort_by_expense_type(request,ext):
    uid=request.session.get("uid")
    explist=Expense.objects.filter(user=uid)
    expt=set()
    for i in explist:
        expt.add(i.expense_type)
        explist=Expense.objects.filter(user=uid,expense_type=ext)
    context={"exp":explist,"expt":expt}
    return render(request,'expense_data_list.html',context)