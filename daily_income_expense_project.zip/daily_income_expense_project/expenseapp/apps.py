from django.apps import AppConfig


class ExpenseappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'expenseapp'
