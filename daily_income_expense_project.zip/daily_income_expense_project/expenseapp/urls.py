from django.contrib import admin
from django.urls import path
from .import views as v

urlpatterns = [
    path("admin/",admin.site.urls),
    path("expe",v.add_expense),
    path("exp_list",v.ExpenseData,name="exp_list"),
    path("delete2/<int:id>",v.Delete_List),
    path("edit_list/<int:id>",v.ExpData_list),
    path('expense_search', v.Expense_Search, name='expense_search'),
    path("extp/<str:ext>",v.sort_by_expense_type,name="ext")
]
